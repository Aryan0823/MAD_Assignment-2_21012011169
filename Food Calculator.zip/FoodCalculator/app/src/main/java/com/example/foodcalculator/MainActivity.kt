package com.example.foodcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import com.example.foodcalculator.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream

class MainActivity : AppCompatActivity() {
    private lateinit var categoryDropdown: Spinner
    private lateinit var foodItemDropdown: Spinner
    private lateinit var gramInput: EditText
    private lateinit var calculateButton: Button
    private lateinit var totalButton: Button
    private lateinit var clearButton: Button
    private lateinit var resultsTable: TableLayout
    private lateinit var totalTable: TableLayout
    private val calculatedResults = mutableListOf<JSONObject>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize references to UI elements
        categoryDropdown = findViewById(R.id.categorySpinner)
        foodItemDropdown = findViewById(R.id.foodItemSpinner)
        gramInput = findViewById(R.id.gramInputEditText)
        calculateButton = findViewById(R.id.calculateButton)
        totalButton = findViewById(R.id.totalButton)
        clearButton = findViewById(R.id.clearButton)
        resultsTable = findViewById(R.id.resultsTable)
        totalTable = findViewById(R.id.totalTable)

        // Populate the Category dropdown
        loadJSONFromAsset("data.json")?.let { database ->
            val categories = database.getJSONObject("Categories")
            val categoryList = categories.keys().asSequence().toList()
            val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categoryList)
            categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            categoryDropdown.adapter = categoryAdapter
        }

        // Update Food Item dropdown based on selected category
        categoryDropdown.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedCategory = categoryDropdown.selectedItem.toString()
                loadJSONFromAsset("data.json")?.let { database ->
                    val foodItems = database.getJSONObject("Categories").getJSONObject(selectedCategory)
                    val foodItemList = foodItems.keys().asSequence().toList()
                    val foodItemAdapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_item, foodItemList)
                    foodItemAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                    foodItemDropdown.adapter = foodItemAdapter
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Calculate button click event
        // Calculate button click event
        // Calculate button click event
        calculateButton.setOnClickListener {
            val selectedCategory = categoryDropdown.selectedItem.toString()
            val selectedFoodItem = foodItemDropdown.selectedItem.toString()
            val grams = gramInput.text.toString().toFloatOrNull() ?: 0.0f

            loadJSONFromAsset("data.json")?.let { database ->
                val foodData = database.getJSONObject("Categories").getJSONObject(selectedCategory).getJSONObject(selectedFoodItem)
                val calculatedParameters = JSONObject()

                calculatedParameters.put("Grams", grams)
                calculatedParameters.put("Energy", (foodData.getDouble("Energy") / 100.0) * grams)
                calculatedParameters.put("Protein", (foodData.getDouble("Protein") / 100.0) * grams)
                calculatedParameters.put("Fat", (foodData.getDouble("Fat") / 100.0) * grams)
                calculatedParameters.put("Minerals", (foodData.getDouble("Minerals") / 100.0) * grams)
                calculatedParameters.put("Fibre", (foodData.getDouble("Fibre") / 100.0) * grams)
                calculatedParameters.put("Carbos", (foodData.getDouble("Carbos") / 100.0) * grams)
                calculatedParameters.put("Calcium", (foodData.getDouble("Calcium") / 100.0) * grams)
                calculatedParameters.put("Phosphorous", (foodData.getDouble("Phosphorous") / 100.0) * grams)
                calculatedParameters.put("Iron", (foodData.getDouble("Iron") / 100.0) * grams)

                // Create a new table row and add it to the table
                val newRow = TableRow(this)
                newRow.layoutParams = TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.WRAP_CONTENT
                )

                val foodItemCell = TextView(this)
                foodItemCell.text = selectedFoodItem
                foodItemCell.layoutParams = TableRow.LayoutParams(
                    0,
                    TableRow.LayoutParams.WRAP_CONTENT,
                    1f
                )

                val categoryCell = TextView(this)
                categoryCell.text = selectedCategory
                categoryCell.layoutParams = TableRow.LayoutParams(
                    0,
                    TableRow.LayoutParams.WRAP_CONTENT,
                    1f
                )

                newRow.addView(categoryCell)
                newRow.addView(foodItemCell)

                val separator = View(this)
                separator.layoutParams = TableRow.LayoutParams(1, TableRow.LayoutParams.MATCH_PARENT)
                separator.setBackgroundColor(resources.getColor(android.R.color.darker_gray))

                newRow.addView(separator)

                for (key in calculatedParameters.keys()) {
                    val nutrientCell = TextView(this)
                    nutrientCell.text = String.format("%.2f", calculatedParameters.getDouble(key))
                    nutrientCell.layoutParams = TableRow.LayoutParams(
                        0,
                        TableRow.LayoutParams.WRAP_CONTENT,
                        1f
                    )
                    newRow.addView(nutrientCell)

                    val separator = View(this)
                    separator.layoutParams = TableRow.LayoutParams(1, TableRow.LayoutParams.MATCH_PARENT)
                    separator.setBackgroundColor(resources.getColor(android.R.color.darker_gray))
                    newRow.addView(separator)
                }

                // Add the row to the table
                resultsTable.addView(newRow)

                // Add calculated results to the array
                calculatedResults.add(calculatedParameters)

                // Clear the input field
                gramInput.text.clear()
            }
        }


        // Total button click event
        totalButton.setOnClickListener {
            val totalParameters = JSONObject()
            totalParameters.put("Grams", 0.0)
            totalParameters.put("Energy", 0.0)
            totalParameters.put("Protein", 0.0)
            totalParameters.put("Fat", 0.0)
            totalParameters.put("Minerals", 0.0)
            totalParameters.put("Fibre", 0.0)
            totalParameters.put("Carbos", 0.0)
            totalParameters.put("Calcium", 0.0)
            totalParameters.put("Phosphorous", 0.0)
            totalParameters.put("Iron", 0.0)

            for (result in calculatedResults) {
                for (key in result.keys()) {
                    totalParameters.put(key, totalParameters.getDouble(key) + result.getDouble(key))
                }
            }

            // Create a new table row for the total and add it to the table
            val newRow = TableRow(this)
            val parameterCell = TextView(this)
            parameterCell.text = "Total"
            newRow.addView(parameterCell)

            val categoryTotalCell = TextView(this)
            categoryTotalCell.text = "Total"
            newRow.addView(categoryTotalCell)

            for (key in totalParameters.keys()) {
                val nutrientCell = TextView(this)
                nutrientCell.text = String.format("%.2f", totalParameters.getDouble(key))
                newRow.addView(nutrientCell)
            }

            totalTable.addView(newRow)
        }

        // Clear button click event
        clearButton.setOnClickListener {
            calculatedResults.clear()
            resultsTable.removeAllViews()
            totalTable.removeAllViews()
        }
    }

    private fun loadJSONFromAsset(fileName: String): JSONObject? {
        var json: String? = null
        try {
            val inputStream: InputStream = assets.open(fileName)
            val size = inputStream.available()
            val buffer = ByteArray(size)
            inputStream.read(buffer)
            inputStream.close()
            json = String(buffer, Charsets.UTF_8)
        } catch (e: IOException) {
            e.printStackTrace()
            return null
        }

        return JSONObject(json)
    }
}